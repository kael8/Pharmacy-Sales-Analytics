<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <form id="stock-form" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title">
                                    <?php echo e(isset($product) ? 'Edit Product' : (isset($batch) ? 'Edit Batch Information' : 'New Batch Information')); ?>

                                </h4>
                            </div>
                            <div class="card-action">
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-sm btn-primary"
                                    role="button">Back</a>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="new-user-info">
                                <div class="row">
                                    <!-- Product Name Input or Select -->
                                    <div class="form-group col-md-6">
                                        <label class="form-label" for="product_name">Product Name: <span
                                                class="text-danger">*</span></label>
                                        <?php if($action == 'edit'): ?>
                                            <!-- Input field for editBatch -->
                                            <input type="text" name="product_name" id="product_name" class="form-control"
                                                value="<?php echo e($batch->product_name); ?>" <?php echo e($action == 'edit' ? 'disabled' : ''); ?>

                                                placeholder="Product" required>
                                        <?php elseif($action == 'add'): ?>
                                            <!-- Select dropdown for addBatch -->
                                            <select name="product_name" class="form-control" id="product_name"
                                                onchange="updateProductDetails()">
                                                <option value="">Select Product</option>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($product->id); ?>" data-price="<?php echo e($product->price); ?>"
                                                        data-cost="<?php echo e($product->cost_price); ?>" data-id="<?php echo e($product->id); ?>"
                                                        data-description="<?php echo e($product->product_description); ?>">
                                                        <?php echo e($product->product_name); ?>


                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php elseif($action == 'addProduct'): ?>
                                            <input type="text" name="product_name" id="product_name" class="form-control"
                                                value="" placeholder="Product" required>
                                        <?php elseif($action == 'editProduct'): ?>
                                            <input type="text" name="product_name" id="product_name" class="form-control"
                                                value="<?php echo e($product->product_name); ?>" placeholder="Product" required>
                                        <?php endif; ?>
                                    </div>

                                    <?php if($action != 'editProduct' && $action != 'addProduct'): ?>
                                        <!-- Product Price -->
                                        <!-- Price -->
                                        <div class="form-group col-md-6">
                                            <label class="form-label" for="product_price">Price: <span
                                                    class="text-danger">*</span></label>
                                            <input type="number" name="product_price" id="product_price"
                                                class="form-control" value="<?php echo e(isset($batch) ? $batch->price : ''); ?>"
                                                placeholder="Price" required>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($action != 'editProduct' && $action != 'addProduct'): ?>
                                        <!-- Cost Price -->
                                        <div class="form-group col-md-6">
                                            <label class="form-label" for="cost_price">Cost Price: <span
                                                    class="text-danger">*</span></label>
                                            <input type="number" name="cost_price" id="cost_price" class="form-control"
                                                value="<?php echo e(isset($batch) ? $batch->cost_price : ''); ?>"
                                                placeholder="Cost Price" required>
                                        </div>

                                        <!-- Quantity -->
                                        <div class="form-group col-md-6">
                                            <label class="form-label" for="product_quantity">Quantity: <span
                                                    class="text-danger">*</span></label>
                                            <input type="number" name="product_quantity" id="product_quantity"
                                                class="form-control" value="<?php echo e(isset($batch) ? $batch->quantity : ''); ?>"
                                                placeholder="Quantity" required>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Product Description -->
                                    <div class="form-group col-md-12">
                                        <label class="form-label" for="product_description">Product Description: <span
                                                class="text-danger">*</span></label>
                                        <textarea name="product_description" id="product_description"
                                            class="form-control" placeholder="Product Description" required
                                            <?php if($action == 'addProduct'): ?><?php elseif($action == 'editProduct'): ?> <?php else: ?> disabled
                                            <?php endif; ?>><?php echo e(isset($product) ? $product->product_description : (isset($batch) ? $batch->product_description : '')); ?></textarea>
                                    </div>

                                    <?php if($action != 'editProduct' && $action != 'addProduct'): ?>
                                        <!-- Expiration Date -->
                                        <div class="form-group col-md-6">
                                            <label class="form-label" for="expiration_date">Expiration Date:</label>
                                            <input type="text" id="expiration_date" name="expiration_date"
                                                class="form-control"
                                                value="<?php echo e(isset($batch) ? $batch->expiration_date : ''); ?>">
                                        </div>
                                    <?php endif; ?>

                                    <!-- Hidden Batch ID for Editing -->
                                    <input type="hidden" name="batch_id" value="<?php echo e($batch->batch_id ?? ''); ?>">
                                    <input type="hidden" name="product_id" id="product_id"
                                        value="<?php echo e(isset($product) ? $product->id : ''); ?>">
                                </div>

                                <!-- Submit Button -->
                                <hr>
                                <div class="row">
                                    <!-- Additional fields can go here -->
                                </div>
                                <button type="button" class="btn btn-primary" onclick="submitForm()">
                                    <?php echo e(isset($product) ? 'Update Product' : (isset($batch) ? 'Update Batch' : 'Add Batch')); ?>

                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<!-- Include Flatpickr CSS and JS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
    integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
    // Initialize Flatpickr on the expiration_date field
    flatpickr("#expiration_date", {
        dateFormat: "Y-m-d",
        minDate: "today", // Prevent selecting past dates
        allowInput: true // Allow manual typing if needed
    });

    // Function to update product details when a product is selected
    function updateProductDetails() {
        const selectElement = document.getElementById('product_name');
        const selectedOption = selectElement.options[selectElement.selectedIndex];

        if (selectedOption.value) {
            console.log(selectedOption.getAttribute('data-id'));
            // Update all related fields with data from selected option

            document.getElementById('product_description').value = selectedOption.getAttribute('data-description');
            document.getElementById('product_id').value = selectedOption.getAttribute('data-id');
        } else {
            // Clear all fields if no product is selected
            document.getElementById('product_quantity').value = '';
            document.getElementById('product_price').value = '';
            document.getElementById('cost_price').value = '';
            document.getElementById('product_description').value = '';
            document.getElementById('product_id').value = '';
            document.getElementById('expiration_date').value = '';
        }
    }

    // Handle form submission for both Add and Edit Batch
    function submitForm() {
        const form = document.getElementById('stock-form');
        const formData = new FormData(form);

        const url = <?php if($action == 'edit'): ?>
            "<?php echo e(route('updateBatch', $batch->id)); ?>"
        <?php elseif($action == 'add'): ?>
            "<?php echo e(route('createBatch')); ?>"
        <?php elseif($action == 'addProduct'): ?>
            "<?php echo e(route('createProduct')); ?>"
        <?php elseif($action == 'editProduct'): ?>
            "<?php echo e(route('updateProduct', $product->id)); ?>"
        <?php endif; ?>;

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            url: url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.message) {
                    alert(response.message);
                    window.location.href = '/inventory/viewInventoryBatches';
                } else {
                    alert(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error('Error:', error);
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.errors && Array.isArray(response.errors)) {
                        var errorMessage = response.errors.join("\n");
                        alert(errorMessage);
                    } else if (response.message) {
                        alert(response.message);
                    } else {
                        alert('An unknown error occurred.');
                    }
                } catch (e) {
                    alert('An error occurred while processing the error response.');
                }
            }
        });
    }
</script><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/inventory/restock.blade.php ENDPATH**/ ?>