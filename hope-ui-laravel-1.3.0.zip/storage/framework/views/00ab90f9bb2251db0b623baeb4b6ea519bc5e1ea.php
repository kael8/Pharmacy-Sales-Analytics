<footer class="footer">
    <div class="footer-body">

        <div class="right-panel">
            ©
            <script>document.write(new Date().getFullYear())</script> <?php echo e(env('APP_NAME')); ?>

        </div>
    </div>
</footer><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/partials/dashboard/_body_footer.blade.php ENDPATH**/ ?>