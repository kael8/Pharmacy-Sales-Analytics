<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title text-center">Sales Insights</h4>
            </div>
            <div class="card-body">
                <form id="filterForm" method="GET">
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="month" class="form-label">Select Month</label>
                            <input type="month" id="month" name="month" class="form-control"
                                value="<?php echo e(request('month')); ?>">
                        </div>
                        <div class="col-md-4 align-self-end">
                            <button type="submit" class="btn btn-primary">Filter</button>
                        </div>
                    </div>
                </form>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Total Sales (₱)</th>
                                <th>Total Quantity Sold</th>
                            </tr>
                        </thead>
                        <tbody id="insightsTableBody">

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#filterForm').on('submit', function (event) {
                event.preventDefault();
                const month = $('#month').val();

                $.ajax({
                    headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                    url: '<?php echo e(route('sales.insights')); ?>',
                    type: 'GET',
                    data: { month: month },
                    success: (response) => {
                        const insightsTableBody = $('#insightsTableBody');
                        insightsTableBody.empty();

                        response.insights.forEach(insight => {
                            insightsTableBody.append(`
                                <tr>
                                    <td>${insight.product_name}</td>
                                    <td>₱${parseFloat(insight.total_sales).toFixed(2)}</td>
                                    <td>${insight.total_quantity}</td>
                                </tr>
                            `);
                        });
                    },
                    error: (xhr) => {
                        console.error('Error:', xhr.responseText);
                        alert('An error occurred while fetching the data.');
                    }
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/sale/getSalesInsight.blade.php ENDPATH**/ ?>