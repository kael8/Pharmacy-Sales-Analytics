<?php if($sales->hasPages()): ?>
    <ul class="pagination">
        
        <?php if($sales->onFirstPage()): ?>
            <li class="disabled"><span>&laquo;</span></li>
        <?php else: ?>
            <li><a href="<?php echo e($sales->previousPageUrl()); ?>">&laquo;</a></li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $sales->currentPage()): ?>
                <li class="active"><span><?php echo e($page); ?></span></li>
            <?php else: ?>
                <li><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($sales->hasMorePages()): ?>
            <li><a href="<?php echo e($sales->nextPageUrl()); ?>">&raquo;</a></li>
        <?php else: ?>
            <li class="disabled"><span>&raquo;</span></li>
        <?php endif; ?>
    </ul>
<?php endif; ?><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/partials/pagination.blade.php ENDPATH**/ ?>