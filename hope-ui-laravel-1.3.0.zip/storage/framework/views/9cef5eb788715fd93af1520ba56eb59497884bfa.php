<div class="card" data-aos="fade-up" data-aos-delay="800">
    <div class="card-header d-flex justify-content-between flex-wrap">
        <div class="header-title">
            <h4 class="card-title">Inventory Status</h4>
        </div>
        <div class="dropdown">
            <a href="#" class="text-secondary dropdown-toggle" id="dropdownInventoryStatus" data-bs-toggle="dropdown"
                aria-expanded="false">
                This week
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownInventoryStatus">
                <li class="dropdown-item-inventory-status" data-period="week">This Week</li>
                <li class="dropdown-item-inventory-status" data-period="month">This Month</li>
                <li class="dropdown-item-inventory-status" data-period="year">This Year</li>
            </ul>
        </div>
    </div>
    <div class="card-body">
        <div style="overflow-x: auto;">
            <canvas id="inventoryStatusChart"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        let inventoryStatusChart;

        // Predefined list of Bootstrap colors
        const bootstrapColors = ['#007bff', '#28a745', '#dc3545', '#ffc107', '#17a2b8'];

        // Function to get color for a specific category
        const getCategoryColor = (index) => {
            return bootstrapColors[index % bootstrapColors.length];
        };

        // Function to update the chart
        const updateChart = (inventoryData, period) => {
            document.getElementById('dropdownInventoryStatus').textContent = `This ${period}`;

            // Create dataset for each product
            const datasets = [{
                label: 'Stock Quantity',
                data: inventoryData.map(dataPoint => parseFloat(dataPoint.stock_quantity)),
                backgroundColor: inventoryData.map((_, index) => getCategoryColor(index))
            }];

            // Create labels for each product
            const labels = inventoryData.map(dataPoint => dataPoint.product_name);

            if (inventoryStatusChart) {
                inventoryStatusChart.data.labels = labels; // Update labels
                inventoryStatusChart.data.datasets = datasets; // Update datasets
                inventoryStatusChart.update();
            } else {
                const ctx = document.getElementById('inventoryStatusChart').getContext('2d'); // Ensure correct canvas element

                inventoryStatusChart = new Chart(ctx, {
                    type: 'bar', // Use 'bar' for a bar chart
                    data: {
                        labels: labels, // Labels for each product
                        datasets: datasets // Dataset with stock quantities
                    },
                    options: {
                        scales: {
                            x: {
                                // Control bar width
                                barPercentage: 0.5,
                                categoryPercentage: 1.0
                            },
                            y: {
                                beginAtZero: true,
                                title: {
                                    display: true,
                                    text: 'Stock Quantity'
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        const label = context.dataset.label || '';
                                        return `${label}: ${context.raw}`; // Show stock quantity
                                    }
                                }
                            }
                        }
                    }
                });
            }
        };

        document.querySelectorAll('.dropdown-item-inventory-status').forEach(item => {
            item.addEventListener('click', function () {
                const period = this.getAttribute('data-period');
                fetchInventoryStatus(period);
            });
        });

        const fetchInventoryStatus = (period) => {
            $.ajax({
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                url: '<?php echo e(url("/inventory/status")); ?>/' + period,
                type: 'GET',
                success: (response) => {
                    updateChart(response, period); // Pass response to update chart
                },
                error: (xhr) => {
                    console.error('Error:', xhr.responseText);
                    const response = JSON.parse(xhr.responseText);
                    const errorMessage = response.message + "\n" + response.errors.join("\n");
                    alert(errorMessage);
                }
            });
        };

        fetchInventoryStatus('week'); // Default period
    });
</script><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/components/inventory-status.blade.php ENDPATH**/ ?>