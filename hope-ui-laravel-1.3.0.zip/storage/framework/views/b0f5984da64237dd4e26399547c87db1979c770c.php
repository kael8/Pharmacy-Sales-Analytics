<?php echo e($slot); ?>

<?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>