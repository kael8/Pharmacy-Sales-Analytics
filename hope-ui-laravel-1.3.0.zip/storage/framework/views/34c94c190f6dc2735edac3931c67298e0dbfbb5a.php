<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>

<?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/partials/dashboard/_body_loader.blade.php ENDPATH**/ ?>