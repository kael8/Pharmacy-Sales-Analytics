<?php $attributes = $attributes->exceptProps(['class' , 'role']); ?>
<?php foreach (array_filter((['class' , 'role']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body d-flex justify-content-between align-items-center">
                <div class="card-title mb-0">
                    <h4 class="mb-0">Calender</h4>
                </div>
                <div class="card-action">
                    <a href="#" class="btn btn-primary" role="button">Back</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/anurag/Documents/hope UI/hope Ui free/hopeUI development/hope-ui/laravel/resources/views/components/header-breadcrumb.blade.php ENDPATH**/ ?>