<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>

<?php /**PATH /home/anurag/Documents/hope UI/zip upload/Hope-UI-2022/hope-ui-2-03-2022/hope-ui-laravel-1.3.0/resources/views/partials/dashboard/_body_loader.blade.php ENDPATH**/ ?>