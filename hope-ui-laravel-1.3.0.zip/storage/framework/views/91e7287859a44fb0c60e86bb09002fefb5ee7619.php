<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <div>
      <div class="row">
         <div class="col-xl-12 col-lg-12">
            <div class="card">
               <div class="card-header">
                  <div class="header-title">
                     <h4 class="card-title text-center">Staff</h4>
                  </div>
               </div>
               <div class="card-body">
                  <div class="bd-example table-responsive">
                     <table class="table table-striped table-hover">
                        <thead>
                           <tr>
                              <th scope="col">#</th>
                              <th scope="col">Name</th>
                              <th scope="col">Email</th>
                              <th scope="col">Phone</th>
                           </tr>
                        </thead>
                        <tbody>
                           <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row">
                            <a href="<?php echo e(url('/admin/staff/editStaff/' . $staff->id)); ?>"
                              class="text-decoration-none text-dark">
                              <?php echo e($loop->iteration); ?>

                            </a>
                          </th>
                          <td>
                            <a href="<?php echo e(url('/admin/staff/editStaff/' . $staff->id)); ?>"
                              class="text-decoration-none text-dark">
                              <?php echo e($staff->fname); ?> <?php echo e($staff->lname); ?>

                            </a>
                          </td>
                          <td>
                            <a href="<?php echo e(url('/admin/staff/editStaff/' . $staff->id)); ?>"
                              class="text-decoration-none text-dark">
                              <?php echo e($staff->email); ?>

                            </a>
                          </td>
                          <td>
                            <a href="<?php echo e(url('/admin/staff/editStaff/' . $staff->id)); ?>"
                              class="text-decoration-none text-dark">
                              <?php echo e($staff->phone); ?>

                            </a>
                          </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\hope-ui-laravel-1.3.0\resources\views/manage-staff/viewStaff.blade.php ENDPATH**/ ?>