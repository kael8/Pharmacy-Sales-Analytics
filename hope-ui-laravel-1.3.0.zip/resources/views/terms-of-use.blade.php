<x-app-layout :assets="$assets ?? []">
<div id="faqAccordion" class="container-fluid">
   <div class="row">
         <div class="col-lg-12">
            <div class="iq-accordion career-style faq-style">
               <div class="card iq-accordion-block">
                     <div class="active-faq clearfix" id="headingOne">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12">
                                    <a role="contentinfo" class="accordion-title" data-bs-toggle="collapse"
                                       data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                       <h6>Lorem ipsum dolor sit </h6>
                                    </a>
                                 </div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse show" id="collapseOne" aria-labelledby="headingOne"
                        data-parent="#faqAccordion">
                        <p class="mb-0">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS. </p>
                     </div>
               </div>
               <div class="card iq-accordion-block">
                     <div class="active-faq clearfix" id="headingTwo">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12"><a role="contentinfo" class="accordion-title collapsed"
                                       data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                                       aria-controls="collapseTwo"><h6> consectetur adipiscing elit
                                       </h6> </a></div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse" id="collapseTwo" aria-labelledby="headingTwo"
                        data-parent="#faqAccordion">
                        <p class="mb-0">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS.
                        </p>
                     </div>
               </div>
               <div class="card iq-accordion-block ">
                     <div class="active-faq clearfix" id="headingThree">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12"><a role="contentinfo" class="accordion-title collapsed"
                                       data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false"
                                       aria-controls="collapseThree"><h6>Etiam sit amet justo non </h6> </a>
                                 </div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse" id="collapseThree" aria-labelledby="headingThree"
                        data-parent="#faqAccordion">
                        <p class="mb-0">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS.
                        </p>
                     </div>
               </div>
               <div class="card iq-accordion-block ">
                     <div class="active-faq clearfix" id="headingFour">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12"><a role="contentinfo" class="accordion-title collapsed"
                                       data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false"
                                       aria-controls="collapseFour"><h6> velit accumsan laoreet </h6> </a>
                                 </div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse" id="collapseFour" aria-labelledby="headingFour"
                        data-parent="#faqAccordion">
                        <p class="mb-0">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS.
                        </p>
                     </div>
               </div>
               <div class="card iq-accordion-block">
                     <div class="active-faq clearfix" id="headingFive">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12"><a role="contentinfo" class="accordion-title collapsed"
                                       data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false"
                                       aria-controls="collapseFive"><h6> Donec volutpat metus in erat </h6> </a></div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse" id="collapseFive" aria-labelledby="headingFive"
                        data-parent="#faqAccordion">
                        <p class="mb-0">Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS.
                        </p>
                     </div>
               </div>
               <div class="card iq-accordion-block">
                     <div class="active-faq clearfix" id="headingSix">
                        <div class="container-fluid">
                           <div class="row">
                                 <div class="col-sm-12"><a role="contentinfo" class="accordion-title collapsed"
                                       data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false"
                                       aria-controls="collapseSix"><h6> quam quis massa tristique </h6> </a>
                                 </div>
                           </div>
                        </div>
                     </div>
                     <div class="accordion-details collapse" id="collapseSix" aria-labelledby="headingSix"
                        data-parent="#faqAccordion">
                        <p class="mb-0">>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia
                        aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt
                        aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft
                        beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat
                        craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore
                        sustainable VHS.
                        </p>
                     </div>
               </div>
            </div>
         </div>
   </div>
</div>
</x-app-layout>
