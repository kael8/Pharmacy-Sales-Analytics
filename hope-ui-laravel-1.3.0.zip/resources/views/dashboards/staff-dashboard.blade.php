<x-app-layout :assets="$assets ?? []">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header  text-black">
                    <h5 class="card-title">Staff Dashboard</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">Welcome to your dashboard. Here you can manage your tasks and view important
                        information.</p>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>