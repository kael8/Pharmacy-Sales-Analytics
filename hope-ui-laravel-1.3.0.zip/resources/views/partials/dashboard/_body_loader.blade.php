<div class="loader simple-loader">
    <div class="loader-body"></div>
</div>

