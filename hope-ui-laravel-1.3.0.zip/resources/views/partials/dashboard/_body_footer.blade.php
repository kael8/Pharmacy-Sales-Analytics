<footer class="footer">
    <div class="footer-body">

        <div class="right-panel">
            ©
            <script>document.write(new Date().getFullYear())</script> {{env('APP_NAME')}}
        </div>
    </div>
</footer>